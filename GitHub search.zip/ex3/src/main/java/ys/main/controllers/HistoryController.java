package ys.main.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ys.main.beans.User;
import ys.main.repo.GithubUser;
import ys.main.repo.GithubUserRepository;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * History Controller is the controller that handles the history requests
 * such as show history and clear history.
 */
@Controller
public class HistoryController {

    /**
     * The github repository used to access the DB.
     */
    @Autowired
    private GithubUserRepository githubUserRepository;

    /**
     * Handles GET requests with url ends with "/history".
     * This function gets the top 10 users that was searched till now and shows them in descended order.
     * @param model used to store the list of github users stored in the data base.
     * @return The history page.
     */
    @GetMapping("/history")

    public String history(Model model) {
        List<GithubUser> listOfGitHubUsers = githubUserRepository.findTop10ByOrderBySearchCountDesc();
        model.addAttribute("listOfGitHubUsers",listOfGitHubUsers);
        return "history";
    }

    /**
     * Handles GET requests with url ends with "/clear".
     * This function clears the github users DB.
     * @param session used to check the status of the u ser permission
     * @return The history page
     */
    @GetMapping("/clear")
    public String clear(HttpSession session){
        User user =(User) session.getAttribute("user");
        if(user.getIsPermitted()){
            githubUserRepository.deleteAllInBatch();
        }
        return "history";
    }
}
