package ys.main.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ys.main.repo.GithubUser;
import ys.main.repo.GithubUserRepository;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Main Controller is the controller that handles the main requests
 * such as show main page , search and error.
 */
@Controller
public class MainController {

    /**
     * The github repository used to access the DB.
     */
    @Autowired
    private GithubUserRepository githubUserRepository;

    /**
     * Handles GET requests with url ends with "/main".
     *
     * @return the main page.
     */
    @GetMapping("/main")
    public String main() {

        return "index";
    }

    /**
     * Handles POST requests with url ends with "/search".
     * This function creates URL connection with Github API and retrieves data about the
     * user name requested.
     * notice that there is no try to connect to github server if the inout is empty!
     * @param search the search value of the form.
     * @param model used to store data to the thymeleaf html file such as showMessage,
     * and the results of the search.
     * @return the main page. if something went wrong during the process returns error page.
     */
    @PostMapping("/search")
     public String search(@RequestParam(name="search", required=true) String search,
                          Model model) {


        String searchValue = search.trim();
        String returnValue = "index";
        if(searchValue.equals("")){ // The case which the input is empty
            model.addAttribute("showMessage",true);
            model.addAttribute("message","Empty input");
        }
        else{
            JSONObject userData = null;
            InputStream inputStream = null;
            try{
                URL url = new URL("https://api.github.com/users/"+ searchValue);
                inputStream = url.openStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader
                        (inputStream, StandardCharsets.UTF_8));
                String jsonText = readAll(rd);
                userData = new JSONObject(jsonText);

                String username = (String) userData.get("login");
                String user_url = (String) userData.get("html_url");
                int followers = (int)userData.get("followers");
                createOrUpdate(username,user_url);
                model.addAttribute("showResults",true);
                model.addAttribute("username",username);
                if(followers == 0){ // The case there is a user without followers
                    model.addAttribute("hasFollowers",false);
                }
                else{
                    model.addAttribute("followers",followers);
                    model.addAttribute("hasFollowers", true);
                }


            } catch (IOException exp){
                model.addAttribute("showMessage",true);
                model.addAttribute("message","No such user");
            }

            catch (JSONException exception){
                returnValue = "error";
            }
            finally {
                try{
                    if(inputStream!=null){
                        inputStream.close();
                    }

                }catch (IOException ex){
                    ex.printStackTrace();
                }
            }
        }

        return returnValue;

    }

    /**
     * Handles GET requests with the url "/error"
     * This implementation is important. the spring mvc "knows" to redirect automatically
     * to this route whenever there is an error.
     * @return error page
     */
    @GetMapping("/error")
    public String error(){

        return "error";
    }

    /**
     * This function reads from the url stream
     * @param rd Reader
     * @return all the data received from the stream is a string.
     * @throws IOException if there is input or output exception.
     */
    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    /**
     * This function gets user name and url of github user
     * and check if its already exist in the DB. if it does it increase the search count,
     * and if not create new one and store it in the DB.
     * @param userName the github user name.
     * @param userUrl the github url.
     */
    private void createOrUpdate(String userName, String userUrl){
        GithubUser githubUser =githubUserRepository.findByUserName(userName);
        if(githubUserRepository.findByUserName(userName) == null){
            GithubUser newUser = new GithubUser(userName, userUrl);
            githubUserRepository.save(newUser);
        }
        else{
            githubUser.appendSearchCount();
        }
    }
}
