package ys.main.controllers;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import ys.main.beans.LoginForm;
import ys.main.beans.User;
import java.io.IOException;

/**
 * Login Controller is the controller that handles the login requests
 * such as landing page / , logout and verify.
 */
@Controller
public class LoginController {


    /**
     * userName is the user name that is a property in the program.
     */
    @Value("${user}")
    private String userName;
    /**
     * password is the password that is a property in the program.
     */
    @Value("${password}")
    private String password;


    /**
     * Handles GET requests with url ends with "/".
     * @param session The session used to access the user property.
     * @param response response used to redirect if in need.
     * @return login page if the user is not permitted, main page if it does
     * and error if something went wrong.
     */
    @GetMapping(value = "/")
    public String login(HttpSession session, HttpServletResponse response) {
        User user =(User)session.getAttribute("user");
        if(user.getIsPermitted()) {
           try{
               response.sendRedirect("/main");
           }catch (IOException exception){
               return "error";
           }
        }
        return "login";
    }


    /**
     * Handles POST requests with url ends with "/verify".
     * this function handles client side fetch calls that send user name and password in the
     * body of POST request. the function checks whether the user name and password that have sent
     * match the constant username and password of the program(admin and 1234) and if so indicates
     * the verification was successful.
     * @param session The session used to access the user property.
     * @param response response used to redirect if in need.
     * @param loginForm used to store the username and password filled in the client side
     * and sent in the body of the post request.
     * @return Json message packed in String format with the result of the verification.
     */
    @PostMapping(value ="/verify")
    public @ResponseBody
    String verify(HttpSession session,HttpServletResponse response, @RequestBody LoginForm loginForm)  {
        JSONObject jsonObject = null;
        try{
            jsonObject = new JSONObject();

            if(loginForm.getUsername().equals(this.userName) && loginForm.getPassword().equals(this.password)){
                jsonObject.put("verified",true);
                User user = (User)session.getAttribute("user");
                user.setIsPermitted(true);
                session.setAttribute("user",user);

            }
            else{
                jsonObject.put("verified",false);
            }
        }catch (JSONException ex){
            try{
                response.sendRedirect("/");
            }catch (IOException exception){
                System.exit(1);
            }
        }

        return jsonObject.toString();
    }

    /**
     * Handles GET requests with url ends with "/logout".
     * this function make a log out to the user and redirects to "/"
     * in the Login Controller.
     * @param session The session used to access the user property.
     * @param response response used to redirect if in need.
     */
    @GetMapping(value = "/logout")
    public void logout(HttpSession session, HttpServletResponse response)  {

      User user =(User) session.getAttribute("user");
      user.setIsPermitted(false);
      session.setAttribute("user",user);
        try{
            response.sendRedirect("/");
        }catch (IOException exception){
            System.exit(1);
        }
    }
}