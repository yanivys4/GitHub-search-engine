package ys.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ys.main.repo.GithubUserRepository;

/**
 * The application class is used to run the program.
 */
@SpringBootApplication
public class Application {

    /**
     * initialize the github repository.
     */
    @Autowired
    public GithubUserRepository GithubuserRepository;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
