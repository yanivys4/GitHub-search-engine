package ys.main.filters;

import org.springframework.web.servlet.HandlerInterceptor;
import ys.main.beans.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * this class intercepts all requests and displays statistics: request processing duration
 */
public class LoggingInterceptor implements HandlerInterceptor {

    /**
     * This function preHandle requests and make sure that sensitive requests will be handle
     * only if the user is permitted. also, the interceptor responsible to make sure the session
     * is always exist and up to date.
     * @param request the request just sent
     * @param response the response that could be handled in the function
     * @param handler object handler part of the override.
     * @return true if the request is ok with the program logic
     * @throws Exception throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler)
            throws Exception {

        if(request.getSession().getAttribute("user") == null){
            request.getSession().setAttribute("user",new User());
        }
        String url = request.getRequestURL().toString();
        if(url.endsWith("/main") || url.endsWith("/history")||url.endsWith("/clear")){
            User user =(User) request.getSession().getAttribute("user");
            if(!user.getIsPermitted()){
                response.sendRedirect("/");
            }
        }



        return true;
    }
}