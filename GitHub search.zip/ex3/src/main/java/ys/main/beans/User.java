package ys.main.beans;

import org.springframework.stereotype.Component;
import java.io.Serializable;
/**
 * User class is a bean used to hold the user permission and used by the session.
 */
@Component
public class User implements Serializable {
    /**
     * boolean variable indicates if the user is permitted or not
     */
    private boolean isPermitted;

    /**
     * Constructs a new User object with permission denied status.
     */
    public User() {
        this.isPermitted =false;
    }

    /**
     *
     * @return The user permission status.
     */
    public boolean getIsPermitted() {
        return isPermitted;
    }

    /**
     * Sets new status of permission.
     * @param permitted new status of permission.
     */
    public void setIsPermitted(boolean permitted) {
        isPermitted = permitted;
    }
}
