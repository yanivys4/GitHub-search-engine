package ys.main.beans;

/**
 * LoginForm class is a bean used to hold the data in the injection of the login form
 * in the request body of the post method.
 */
public class LoginForm {
    /**
     * a string that gets the username passed by the POST request body
     */
    private String username;
    /**
     * a string that gets the password passed by the POST request body
     */
    private String password;

    /**
     *
     * @return the username of the login form
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @return the password of the login form
     */
    public String getPassword() {
        return password;
    }
}
