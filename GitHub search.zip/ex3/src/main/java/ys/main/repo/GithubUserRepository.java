package ys.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * The github user repository used to access the DB.
 */
public interface GithubUserRepository extends JpaRepository<GithubUser, Long> {
   GithubUser findByUserName(String userName);
   List<GithubUser> findTop10ByOrderBySearchCountDesc();
}
