package ys.main.repo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

/**
 * GithubUser is a class that holds the data of the gitHub_user table.
 */
@Entity
public class GithubUser {

    /**
     * id used in the table
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    /**
     * the github user name
     */
    @NotBlank(message = "Name is mandatory")
    private String userName;
    /**
     * the github user url
     */
    @NotBlank(message = "Url is mandatory")
    private String url;

    /**
     * search count
     */
    private long searchCount;

    /**
     * default constructor
     */
    public GithubUser() {}

    /**
     * Constructs a new github user
     * @param userName the github user name
     * @param url the github url
     */
    public GithubUser(String userName, String url) {
        this.userName = userName;
        this.url = url;
        this.searchCount = 1; // starts with 1 searches
    }

    /**
     *
     * @return the github user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     *
     * @return the github user url
     */
    public String getUrl() {
        return url;
    }

    /**
     * append search count of the github user
     */
    public void appendSearchCount() {
        this.searchCount ++ ;
    }

    /**
     *
     * @return the search count
     */
    public long getSearchCount() {
        return searchCount;
    }

    /**
     *
     * @return String represents the github user
     */
    @Override
    public String toString() {
        return userName + ": " + searchCount;
    }
}


