document.addEventListener('DOMContentLoaded',function () {
    document.getElementById("message").style.display = "none";
    document.getElementById("form").addEventListener('click',function () {
        document.getElementById("message").style.display = "none";
    },false);

    document.getElementById("submit").addEventListener('click',function() {

        let userName = document.getElementById("usernameBox").value;
        let password = document.getElementById("password").value;
        var myParams = { method: 'POST',
            body: JSON.stringify({username:userName, password: password}),
            headers: { "Content-Type": "application/json"}
        };
        fetch("/verify", myParams)
            .then(handleGeneralErrors)
            .then(response=> response.json())
            .then(res=> useJson(res))
            .catch(function(err){
                console.log('Fetch Error:',err);
            });

    },false);

    /*
    This function handles general errors during fetch
     */
    function handleGeneralErrors(response) {
        if (!response.ok) {
            throw(Error);
        }
        return response;
    }

    /*
    This function uses the json received in the response of the fetch call and checks
    if the answer is positive or not. if its positive redirects to the main page
    if not shows message.
     */
    function useJson(res){
        let flag = res.verified;
        if(flag === true){
            window.location.href="/main";
        }

        else{
            document.getElementById("message").style.display = "block";
        }
    }
},false);

